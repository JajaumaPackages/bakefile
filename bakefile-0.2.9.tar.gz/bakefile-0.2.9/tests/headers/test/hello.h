#define func printf

