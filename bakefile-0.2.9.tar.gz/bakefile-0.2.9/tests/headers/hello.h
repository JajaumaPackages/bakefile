// we use an header file in a subfolder to test if bakefile's <headers> tag
// (see headers.bkl) correctly handles headers prefixed with a path
#include "test/hello.h"
