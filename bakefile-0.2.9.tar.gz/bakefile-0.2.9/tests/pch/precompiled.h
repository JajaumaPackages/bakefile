
#include <stdio.h>

#define MESSAGE "Hello, world! (precompiled headers test)\n"
