
#include "precompiled.h"

int main()
{
    printf(MESSAGE);
    return 0;
}
