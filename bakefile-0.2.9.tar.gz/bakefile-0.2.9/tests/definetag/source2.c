#include <stdio.h>

int useless()
{
    return 0;
}
