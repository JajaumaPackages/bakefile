
extern void print();

int main()
{
    print();
    return 0;
}
