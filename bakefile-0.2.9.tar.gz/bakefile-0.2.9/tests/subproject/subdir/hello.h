
#define HELLO_BANNER "Hello, world!"

#define HELLO_BANNER "Hello, world!"
