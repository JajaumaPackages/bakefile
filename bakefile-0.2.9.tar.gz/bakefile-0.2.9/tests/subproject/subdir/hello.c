#include <stdio.h>
#include "hello.h"

int main()
{
    printf("%s\n", HELLO_BANNER);
    return 0;
}
