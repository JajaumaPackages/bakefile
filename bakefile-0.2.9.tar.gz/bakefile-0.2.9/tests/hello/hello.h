
#define HELLO_BANNER "Hello, world!"
