#include <stdio.h>

int hello3()
{
    printf("Hello, world!");
    return 0;
}
