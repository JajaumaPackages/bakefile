#include <stdio.h>

int hello1()
{
    printf("Hello, world!");
    return 0;
}
