#include <stdio.h>

int hello2()
{
    printf("Hello, world!");
    return 0;
}
