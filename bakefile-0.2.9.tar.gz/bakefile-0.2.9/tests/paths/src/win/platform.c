
void platform_windows()
{
}
