
void platform_linux()
{
}
